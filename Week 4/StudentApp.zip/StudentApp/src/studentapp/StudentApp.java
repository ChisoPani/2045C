/*
Title:             StudentApp
Desc:              This program prints a message on the screen
Files:             StudentApp.java
Semester:          Fall 2021
Author name:       Meelan Pokhrel
Author email:      pokhremn@mail.uc.edu
 */
package studentapp;

public class StudentApp {

    public static void main(String[] args) {
        
         
    }
    
}
