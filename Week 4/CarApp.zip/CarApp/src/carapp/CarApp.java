/*
Title:             carapp
Desc:              This program simulates a car driving and adding fuel, and fuel left.
Files:             CarApp.java
Semester:          Fall 2021
Author name:       Meelan Pokhrel
Author email:      pokhremn@mail.uc.edu
 */
package carapp;

/**
 *
 * @author meela
 */
public class CarApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
