/*
Title:             RectangleApp
Desc:              This program calculates area and circumference of a rectangle.
Files:             RectangleApp.java
Semester:          Fall 2021
Author name:       Meelan Pokhrel
Author email:      pokhremn@mail.uc.edu
 */
package rectangleapp;
public class RectangleApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
