/*
Title:             address
Desc:              This program prints out house addreses.
Files:             AddressApp.java
Semester:          Fall 2021
Author name:       Meelan Pokhrel
Author email:      pokhremn@mail.uc.edu
 */
package addressapp;

public class AddressApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
