/*
Title:             HelloFall
Desc:              This program prints a message on the screen
Files:             HelloFall.java
Semester:          Fall 2021
Author name:       Meelan Pokhrel
Author email:      pokhremn@mail.uc.edu
 */
package hellofall;

/**
 *
 * @author Meelan Pokhrel
 */
public class HelloFall {

    public static void main(String[] args) {

        System.out.println("In this fall, I'm taking the computer programming II course");
        System.out.println("I plan on keeping track of due dates and deadlines and staying on top of my assignments");
        System.out.println("I hope to learn new and exicting code that will further my knowledge in java");

    }

}
