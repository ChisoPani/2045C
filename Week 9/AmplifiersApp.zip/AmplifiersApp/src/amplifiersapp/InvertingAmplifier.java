/**
Title: amplifiersapp
Desc: Inverts Amplifier
Files: InvertingAmplifier
Semester: Fall 2021
Author name: Meelan Pokhrel
Author email: pokhremn@mail.uc.edu
 */
package amplifiersapp;

public class InvertingAmplifier extends Amplifier {

   public InvertingAmplifier(double r1, double r2) {
       super(r1, r2);

   }

   @Override
   public double getGain() {

       double gain = -(getResistance2() / getResistance1());
       return gain;
   }

   @Override
   public String getDescription() {
       return "Inverting Amplifier: R1 = " + getResistance1() + ", R2 = " + getResistance2();

   }

}