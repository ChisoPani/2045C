/**
Title: amplifiersapp
Desc: Amplifer app
Files: amplifiersapp
Semester: Fall 2021
Author name: Meelan Pokhrel
Author email: pokhremn@mail.uc.edu
 */
package amplifiersapp;

public abstract class Amplifier {
   private double r1;
   private double r2;

   public Amplifier(double r1, double r2) {
       super();
       this.r1 = r1;
       this.r2 = r2;
   }

   public double getResistance1() {
       return r1;
   }
   public void setResistance1(double r1) {
       this.r1 = r1;
   }

   public double getResistance2() {
       return r2;
   }
   public void setResistance2(double r2) {
       this.r2 = r2;
   }

   public abstract double getGain();

   public abstract String getDescription();
}