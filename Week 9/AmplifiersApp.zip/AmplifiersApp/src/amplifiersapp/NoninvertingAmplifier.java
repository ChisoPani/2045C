/**
Title: amplifiersapp
Desc: Non-Inverting Amplifier
Files: NoninvertingAmplifier
Semester: Fall 2021
Author name: Meelan Pokhrel
Author email: pokhremn@mail.uc.edu
 */
package amplifiersapp;

public class NoninvertingAmplifier extends Amplifier {

   public NoninvertingAmplifier(double r1, double r2) {
       super(r1, r2);

   }

   @Override
   public double getGain() {
       double gain = (1 + (getResistance2() / getResistance1()));
       return gain;
   }
   @Override
   public String getDescription() {

       return "Non Inverting Amplifier: R1 = " + getResistance1() + ", R2 = " + getResistance2();
   }

}