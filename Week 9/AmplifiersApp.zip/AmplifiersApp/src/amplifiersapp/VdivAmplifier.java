/**
Title: amplifiersapp
Desc: Voltage Divider Amplifier
Files: VdivAmplifier
Semester: Fall 2021
Author name: Meelan Pokhrel
Author email: pokhremn@mail.uc.edu
 */
package amplifiersapp;

public class VdivAmplifier extends Amplifier  {

   public VdivAmplifier(double r1, double r2) {
       super(r1, r2);
   }
   @Override
   public double getGain() {
       double gain = (getResistance2() / (getResistance1() + getResistance2()));
       return gain;
   }
   @Override
   public String getDescription() {
       return "Voltage Divider Amplifier: R1 = " + getResistance1() + ", R2 = " + getResistance2();
   }

}