/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package questionsapp;

import java.util.Scanner;
/*
Title:             QuestionApp
Desc:              This program asks questions to user.
Files:             FillInQuestion.java
Semester:          Fall 2021
Author name:       Meelan Pokhrel
Author email:      pokhremn@mail.uc.edu
 */

class FillInQuestion extends Question {

    public FillInQuestion() {

        super();

    }

    @Override

    public void setText(String questionText) {

        Scanner scanner = new Scanner(questionText);

        scanner.useDelimiter("_");

        String question = scanner.next();

        String answer = scanner.next();

        question += "___";

        scanner.close();

        super.setText(question);

        super.setAnswer(answer);

    }

}
