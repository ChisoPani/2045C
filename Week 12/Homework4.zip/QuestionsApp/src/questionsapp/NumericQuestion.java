/*
Title:             QuestionApp
Desc:              This program asks questions to user.
Files:             NumericQuestion.java
Semester:          Fall 2021
Author name:       Meelan Pokhrel
Author email:      pokhremn@mail.uc.edu
 */

package questionsapp;

class NumericQuestion extends Question {

    double answer;

    public NumericQuestion() {

        super();

    }

    public void setAnswer(double correctResponse) {

        answer = correctResponse;

    }

    @Override

    public boolean checkAnswer(String response) {

        double givenanswer = Double.parseDouble(response);

        return Math.abs(givenanswer - answer) <= 0.01;

    }

}
